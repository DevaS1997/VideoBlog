import { createSlice } from "@reduxjs/toolkit";
import { v4  as uuidv4 } from 'uuid';
const initialState = {
    taskList: [],
    selectedTask: {}
}

const tasksSlice = createSlice({
    name: "tasks",
    initialState,
    reducers: {
        addTask: (state, action) => {
            const id = uuidv4();
            state.taskList.push({...action.payload,id})
        },
        removeTask: (state, action) => {
            state.taskList = state.taskList.filter((task) => task.id !== action.payload.id);
        },
        updateTask: (state, action) =>{
            const index = state.taskList.findIndex(task=>task.id===action.payload.id);
            state.taskList[index] = action.payload;
        },
        selectedTask:(state,action)=>{
            state.selectedTask=action.payload
        }
    }
});

export const { addTask,removeTask,updateTask,selectedTask } = tasksSlice.actions;

export default  tasksSlice.reducer;
