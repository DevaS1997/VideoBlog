import React, { Component } from "react";
import './Home.css'

export default class Home extends Component {
//   constructor(props) {
//     super(props);
//     // this.state = {
//     //   name: "",
//     //   email: "",
//     //   message: ""
//     // };
//   }
//   handleChange = (e) => {
//     const name = e.target.name;
//     const value = e.target.value;
//     this.setState({...this.state,[name]: value});
//   }
//   handleSubmit = ()=>{
//     alert(`Welcome ${this.state.name}`);
//   }
  render() {
    return (
      <>
        {/* <div style={{height:'100px',width:'100px',border:'1px solid red',marginTop:'10px'}}>Home</div> */}
        <div className="border text-center p-5 m-2">Home</div>
      </>
    );
  }
}
