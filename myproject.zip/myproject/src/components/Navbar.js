import React from 'react'

function Navbar() {
    return (
        <div className='text-center mt-4'>
          <h1 className='text-primary mb-4'>Project Management</h1>  
          <p className='text-muted'>Current 0 task(s) pending </p>
        </div>
    )
}

export default Navbar
