import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'

function Navbar() {
  const [task,setTask] = useState([]);
  const tasks = useSelector(state=>state.tasks.taskList)
  useEffect(()=>{
    setTask(tasks)
  },[tasks])
    return (
        <div className='text-center mt-4'>
          <h1 className='text-primary mb-4'>Project Management</h1>  
          <p className='text-muted'>Current {task.length} task(s) pending </p>
        </div>
    )
}

export default Navbar
