import React from 'react'

function Form({data,handleChange}) {
    return (
        <>
            <div className="mb-3">
                <label htmlFor="title" className="form-label">Title </label>
                <input type="text" id="title" name="title" className="form-control" placeholder='Enter Title'
                    value={data.title || ''}
                    onChange={handleChange}
                />
            </div>
            <div className="mb-3">
                <label htmlFor="description" className="form-label">Description </label>
                <input type="text" id="description" name="description" className="form-control" placeholder='Enter Description'
                    value={data.description || ''}
                    onChange={handleChange}
                />
            </div>
            <div className="mb-3">
                <label htmlFor="description" className="form-label">Priority </label>
                <select name='priority' className='form-select'
                    value={data.priority || ''}
                    onChange={handleChange}
                >
                    <option value='low'>Low Priority</option>
                    <option value='medium'>Medium Priority</option>
                    <option value='high'>High Priority</option>
                </select>
            </div>
        </>
    )
}

export default Form
