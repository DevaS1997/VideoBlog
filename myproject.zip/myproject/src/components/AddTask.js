import React, { useState } from 'react';
import Form from './Form';
import { useDispatch } from 'react-redux';
import { addTask } from '../slices/taskSlice';

function AddTask(props) {
    const [data, setData] = useState({});
    const [isError, setIsError] = useState(false);
    const dispatch = useDispatch();
    // const selectedTask = useSelector(state => state.tasks.selectedTask)
    const handleChange = (e) => {
        const name = e.target.name;
        console.log(name)
        const value = e.target.value;
        setData(prevState => ({ ...prevState, [name]: value }));
    }

    const handleSubmit =(e)=>{
        e.preventDefault();
        console.log(data)
        if(Object.keys(data).length !== 3){
            setIsError(true);
        }else{
            setIsError(false);
            dispatch(addTask(data))
        }
        setData({})
    }
    // useEffect(()=>{
    //     // if(props.hideAdd){}
    //     // if(selectedTask){
    //     //     setData(selectedTask)
    //     // }
    // },[selectedTask])
    return (
        <>  
            <p className={isError ? 'text-danger' : 'd-none'} >Please fill all the fields</p>
            <form onSubmit={e => handleSubmit(e)} className="">
                <Form data={data} handleChange={handleChange} />
                <div className='text-end'>
                    <button type='submit' className='btn btn-primary'>Add Task</button> 
                </div>

                {/* <div className="mb-3">
                <label htmlFor="email" className="m-3">Email: </label>
                <input type="email" id="email" name="email" className="form-control" value={data.email||''} onChange={handleChange} />
            </div>
            <div className="mb-3">
                <label htmlFor="message" className="m-3">Message: </label>
                <textarea id="message" type="text" className="w-100 h-75" rows="4" name="message" value={data.message||''} onChange={handleChange}/>
            </div>
                <input type='text' name='title' placeholder='Title' /><br/>
                <textarea name='description' placeholder='Description'></textarea><br/>
                <div className="dateAndTime">
                    Date:  
                    <input type='date' name='dueDate' /><br/>
                    Time:  
                    <input type='time' name='dueTime' />
                </div>  
                <select name='priority'>
                    <option value='low'>Low Priority</option>
                    <option selected value='medium'>Medium Priority</option>
                    <option value='high'>High Priority</option>
                </select><br/>
                <button type='submit'>Add Task</button> */}
            </form>
        </>
    )
}

export default AddTask
