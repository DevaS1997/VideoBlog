import React, { useState } from 'react'
import Form from './Form'


function UpdateTask() {
    const [data, setData] = useState({});
    const handleUpdate = ()=>{

    }
    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setData(prevState => ({ ...prevState, [name]: value }));
    }
    return (
        <>
            <div className="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header border-0">
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <Form data={data} handleChange={handleChange} />
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" className="btn btn-primary" data-bs-dismiss="modal" onClick={handleUpdate}>Update</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default UpdateTask
