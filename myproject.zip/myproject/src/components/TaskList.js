import React, { useEffect, useState } from 'react'
import UpdateTask from './UpdateTask'
import { useDispatch, useSelector } from 'react-redux'
import { selectedTask,removeTask } from '../slices/taskSlice';

function TaskList() {
    const [taskList, setTaskList] = useState([])
    const dispatch = useDispatch();
    const tasks = useSelector(state => state.tasks.taskList)  //acceder a los datos del store de Redux
    const handleUpdate = (task)=>{
        dispatch(selectedTask(task))
    }
    const handleDelete = (id)=>{
        dispatch(removeTask(id))
    }
    useEffect(() => {
        setTaskList(tasks);
    }, [tasks])
    return (
        <>
            <table className="table table-striped table-bordered mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Priority</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        taskList && taskList.map((task,index) => (
                            <tr key={index}>
                                <td>{index +1}</td>
                                <td>{task.title}</td>
                                <td>{task.description}</td>
                                <td>{task.priority}</td>
                                <td>
                                    <button type="button" className="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                                    onClick={()=>handleUpdate(task)}
                                    ><i className='bi bi-pencil-fill'></i></button>&nbsp;
                                    <button type="button" className="btn btn-sm btn-danger" onClick={()=>{handleDelete(task)}}><i className='bi bi-trash-fill'></i></button>
                                </td>
                            </tr>
                        ))
                    }

                </tbody>
            </table>
            <UpdateTask />
        </>
    )
}

export default TaskList
