
import './App.css';
import AddTask from './components/AddTask';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';
// import { useEffect, useState } from 'react';

function App() {
  // const  [count, setCount] = useState(0);
  // const  [data, setData] = useState({});
  // const handleChange = (e) => {
  //   const name = e.target.name;
  //   const value = e.target.value;
  //   setData(prevState => ({...prevState,[name]: value}));
  // }
  // useEffect(() => {
  //   // componentDidMount and componentDidUpdate
  //   document.title = `You clicked ${count} times`;
  // }, [count]);
  return (
    <div className='container'>
      <Navbar />
      <div className='row justify-content-center'>
        <div className='col-md-5'>
          <AddTask />
          <TaskList/>
        </div>
      </div>
    </div>
  );
}

export default App;

